#version 450

layout(location = 0) in vec2 fragUv;

layout(location = 0) out vec4 outColor;

//TODO: Assignment 2.8
// Add a binding for a two-dimensional sampler and use the UV coordinates to sample the texture.
layout(set = 0, binding = 0) uniform sampler2D diffuseTexture;

//TODO: Assignment 2.12
// Add the binding for the material uniform buffer and, in case the material does not have a texture,
// use the uniform base color instead.

layout(set = 0, binding = 1) uniform MaterialUniformBuffer {vec4 baseColor; int hasTexture; float alphaCutoff;} material;

void main() {
    if(material.hasTexture != 0){
        outColor = texture(diffuseTexture, fragUv);
        if (outColor.a < material.alphaCutoff) {// Ausschluss fast transparenter Blattränder
            discard;
        }
    } else {
        outColor = material.baseColor;
    }
}